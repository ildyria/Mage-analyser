<?php

DEFINED('MA') or die('HACKING ATTEMPT!');

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"'."\n";
echo '"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">'."\n";
echo '<html xml:lang="fr" xmlns="http://www.w3.org/1999/xhtml">'."\n";
echo '<head>'."\n";
echo "\t".'<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />'."\n";
echo "\t".'<meta name="DESCRIPTION" content="Analyse de log de mage" />'."\n";
echo "\t".'<meta name="keywords" content="log" />'."\n";
echo "\t".'<meta name="author" content="Ildyria" />'."\n";
echo "\t".'<meta name="date-creation-ddmmyyyy" content="04062010" />'."\n";
echo "\t".'<link rel="icon" href="./images/favicon.ico" type="image/x-icon" />'."\n";
echo "\t".'<link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon" />'."\n";
echo "\t".'<title>Mage analyser</title>'."\n";
echo "\t".'<link rel="stylesheet" type="text/css" href="site.css" />'."\n";
echo "\t".'<script type="text/javascript" src="js/form.js" ></script>'."\n";
echo '</head>'."\n";
echo '<body>'."\n";
echo '<div id=\'barre\'><a href="index.php"><img src="images/barre.png" style="border: 0px;" alt="&nbsp;" /></a></div>'."\n";
?>