<?php

DEFINED('MA') or die('HACKING ATTEMPT!');

echo '<div style="text-align: center; padding-top: 15px;">'."\n";
echo "\t".'<span class="c0" style="font-weight: bold;">&copy;2010-2011 Ildyria</span><br />'."\n";
echo '</div>'."\n";
echo '</div>'."\n";
echo '</body>'."\n";
echo '</html>'."\n";

?>